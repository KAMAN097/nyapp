import React from 'react';
import Card from './Card';

const App =()=>{
    return(
       <div>
           <Card image="https://www.grandewreckers.com.au/wp-content/uploads/2020/07/cropped-logo-grande-wreckers-compressor.png" content="asdasdasdada asdasd asdasdas dasdadadadadasda saasd"/>
           <Card image="https://www.grandewreckers.com.au/wp-content/uploads/2020/07/cropped-logo-grande-wreckers-compressor.png" content="aasadqadsa saasd"/>
           <Card image="https://www.grandewreckers.com.au/wp-content/uploads/2020/07/cropped-logo-grande-wreckers-compressor.png" content="aproiiaisudiaidaadadasda saasd"/>
           <Card image="https://www.grandewreckers.com.au/wp-content/uploads/2020/07/cropped-logo-grande-wreckers-compressor.png" content="asdasdasdada asdasd asdasdas dasdadadadadasda saasd"/>
           <Card image="https://www.grandewreckers.com.au/wp-content/uploads/2020/07/cropped-logo-grande-wreckers-compressor.png" content="asdasdasdada asdasd asdasdas dasdadadadadasda saasd"/>
           <Card image="https://www.grandewreckers.com.au/wp-content/uploads/2020/07/cropped-logo-grande-wreckers-compressor.png" content="asdasdasdada asdasd asdasdas dasdadadadadasda saasd"/>
           <Card image="https://www.grandewreckers.com.au/wp-content/uploads/2020/07/cropped-logo-grande-wreckers-compressor.png" content="asdasdasdada asdasd asdasdas dasdadadadadasda saasd"/>
        </div>
    );
}

export default App;