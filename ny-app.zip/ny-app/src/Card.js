import  React from 'react';


const Card = ({image, content}) =>{
    return(
        <div style={{padding:'20px'}}>
                <div style={{border:'2px solid black'}}>
                    <img src={image}  style={{width:"200px",height:"200px"}} alt="kangna"/>
                    
<p>{content}</p>                </div>
        </div>
    )
}

export default Card;
